﻿namespace test1.Models
{
    public class Doctors
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Specialty { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
    }
}
