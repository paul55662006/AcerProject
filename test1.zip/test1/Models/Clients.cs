namespace test1.Models
{
	public class Clients
    {
        public int ClientId { get; set; } // �D��
        public string Name { get; set; }
        public string Phone { get; set; }
        public string PetType { get; set; }
        public string PetName { get; set; }
        public int PetAge { get; set; }
        public string Symptoms { get; set; }
        public DateTime Date { get; set; }
        public string TimeSlot { get; set; }
    }
}
